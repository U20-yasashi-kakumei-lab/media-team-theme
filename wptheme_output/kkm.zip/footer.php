    <script src="./code.js"></script>
    <footer>
        Copyright (C) 2018 やさしいかくめいラボ. All rights reserved.
    </footer>

<?php wp_footer(); ?>
</body>
</html>