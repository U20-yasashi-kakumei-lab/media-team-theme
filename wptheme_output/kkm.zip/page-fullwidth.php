<?php
/**
 * Template Name: Full-width
 */
get_header(); ?>

    <!-- Header -->
    <header>
        <div class="centering">
            <a href="">
                <img src="./img/head_white.png" class="top-half">
            </a>
        </div>
    </header>

    <!-- Menu area -->
    <section id="menuboard">
        <div id="menuarea" class="menu-top-container">
            <ul id="menu-top" class="menu">
                <li id="menu-item-331" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-331"><a
                        href="">ニュース</a></li>
                <li id="menu-item-332" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-289 current_page_item menu-item-332"><a
                        href="">インタビュー</a></li>
                <li id="menu-item-164" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-164"><a
                        href="">イベント</a></li>
                <li id="menu-item-164" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-164"><a
                        href="">読み物</a></li>
            </ul>
        </div>
    </section>

    <!-- Menu bar -->
    <section class="menubar">
        <div class="centering">

            <!-- Menu Button -->
            <a href="javascript:void(0)" id="menubtn">
                <i id="menuIco" class="fas fa-bars"></i>
            </a>

            <!-- Social Button -->
            <a href="" class="snsbtn tw">
                <i class="fab fa-twitter"></i>
            </a>

            <a href="" class="snsbtn insta">
                <i class="fab fa-instagram"></i>
            </a>

        </div>
    </section>

    <!-- Main content -->
    <div class="wrapper">

        <!-- Left side -->
        <div class="full">

            <section class="article">

                <?php if(have_posts()): while(have_posts()):the_post(); ?>
                <!-- Title -->
                <h1 class="title"><?php the_title(); ?></h1>

                <!-- Article content -->
                <article><?php the_content(); ?></article>

                <!-- Posted date -->
                <div class="date"><?php echo get_the_date( 'Y/m/d' ); ?></div>
					
				<?php endwhile; ?>
            <?php else : ?>
            <h2>Not found</h2>
            <?php endif; ?>
            </section>


        </div>
    </div>

<?php get_footer(); ?>